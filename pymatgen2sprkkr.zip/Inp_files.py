from pathlib import Path

from pymatgen.core import Structure

scf_inp_template = '''###############################################################################
#  SPR-KKR input file    *SCF.inp 
###############################################################################

CONTROL  DATASET     = {system} 
         ADSI        = SCF 
         POTFIL      = {system}.pot 
         PRINT = 0    

MODE     SP-SREL 

TAU      BZINT= POINTS  NKTAB= {nktab} 

ENERGY   GRID={5}  NE={30} 
         ImE=0.0 Ry   EMIN={emin} Ry

SCF      NITER=200 MIX=0.05 VXC=PBE
         TOL=0.00001  MIXOP=0.20  ISTBRY=1 
         QIONSCL=0.80 
         NOSSITER
         MSPIN={{magmoms}} 
'''

replaces_scf = {'{system}': None,
                '{nktab}': '4000',
                '{emin}': '-0.2',
                '{magmoms}': None}

jxc_inp_template = '''###############################################################################
#  SPR-KKR input file    *JXC.inp 
#  created by xband on Sat 14 Jun 22:38:43 BST 2025
###############################################################################
 
CONTROL  DATASET     = {system} 
         ADSI        = JXC 
         POTFIL      = {system}.pot 
         PRINT = 0    
 
MODE     SP-SREL 
 
TAU      BZINT= POINTS  NKTAB= {nktab} 
 
ENERGY   GRID={5}  NE={30} 
         EMIN={emin} Ry
 
TASK     JXC   CLURAD={cluster_radius}
'''

replaces_jxc = {'{system}': None,
                '{nktab}': '2000',
                '{emin}': '-0.2',
                '{cluster_radius}': '2.5'}

templates = {'scf': scf_inp_template,
             'jxc': jxc_inp_template}

replaces = {'scf': replaces_scf,
            'jxc': replaces_jxc}


def get_system_name(structure: Structure):
    return structure.composition.to_pretty_string().replace('1', '')


def create_inp_file(type: str, tags_to_replace: dict, output_path: Path):
    if type not in ['scf', 'jxc']:
        raise KeyError('Incorrect type of input file, try "scf" or "jxc"')
    inp = templates[type]
    for key, val in tags_to_replace.items():
        inp = inp.replace(key, val)
    with open(f'{output_path}/*{type}.inp', 'w') as f:
        f.write(inp)


def get_magmom_str(structure_primitive: Structure):
    magmom = []
    for site in structure_primitive:
        spin = site.species.elements[0].spin if (hasattr(site.species.elements[0], 'spin')) else 0
        spin = 0 if (spin == None) else spin
        magmom.append(spin)
    return magmom


def main(structure: Structure):

    replaces_scf['{system}'] = get_system_name(structure)
    replaces_scf['{magmoms}'] = get_magmom_str(structure)


if __name__ == '__main__':
    main()